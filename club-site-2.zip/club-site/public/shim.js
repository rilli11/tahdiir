// يحاكي واجهة claude.use('db'|'user'|'downloads') فوق سيرفر Node (الباك إند).
(function(){if(window.claude)return;
 const J=(u,o)=>fetch(u,o).then(async r=>{if(!r.ok)throw Object.assign(new Error('HTTP '+r.status),{code:r.status});return r.json()});
 const H={'Content-Type':'application/json'},E=encodeURIComponent;
 const subs={};let es=null;
 const listen=()=>{if(es)return;es=new EventSource('/api/events');es.onmessage=ev=>{try{const c=JSON.parse(ev.data).c;(subs[c]||[]).forEach(f=>f())}catch(e){}};};
 const snap=l=>({docs:l.map(x=>({id:x.id,data:()=>x.data}))});
 const col=(n,q)=>{q=q||{};const q2=o=>col(n,{...q,...o});
  const list=async()=>{let l=await J('/api/c/'+E(n));if(q.ob){const[k,d]=q.ob;l.sort((a,b)=>((a.data[k]>b.data[k])-(a.data[k]<b.data[k]))*(d==='desc'?-1:1))}if(q.lim)l=l.slice(0,q.lim);return l};
  return{orderBy:(k,d)=>q2({ob:[k,d]}),limit:x=>q2({lim:x}),where:()=>col(n,q),
   get:async()=>snap(await list()),
   onSnapshot(cb,er){const f=()=>list().then(l=>cb(snap(l))).catch(e=>er&&er(e));f();(subs[n]=subs[n]||[]).push(f);listen();return()=>{subs[n]=subs[n].filter(x=>x!==f)}},
   doc:id=>({set:d=>J('/api/c/'+E(n)+'/'+E(id),{method:'PUT',headers:H,body:JSON.stringify(d)}),
    update:d=>J('/api/c/'+E(n)+'/'+E(id),{method:'PATCH',headers:H,body:JSON.stringify(d)}),
    delete:()=>J('/api/c/'+E(n)+'/'+E(id),{method:'DELETE'}),
    get:async()=>{try{const r=await J('/api/c/'+E(n)+'/'+E(id));return{exists:true,id,data:()=>r.data}}catch(e){return{exists:false,id,data:()=>undefined}}}}),
   add:async d=>{const id=Date.now().toString(36)+Math.random().toString(36).slice(2,6);await J('/api/c/'+E(n)+'/'+id,{method:'PUT',headers:H,body:JSON.stringify(d)});return{id}}}};
 const dl={save:async({filename,data})=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data]));a.download=filename;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)}};
 window.claude={use:async k=>k==='db'?{collection:n=>col(n)}:k==='user'?{canEdit:()=>true,name:'',id:'local'}:k==='downloads'?dl:null};
})();
