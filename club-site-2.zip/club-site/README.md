# باك إند موقع لجنة التنظيم

## التشغيل
```
node server.js          # يتطلب Node 18+ ، بدون npm install
PORT=8080 DATA=/path/db.json node server.js
```
ثم افتح http://localhost:3000 — الموقع نفسه (public/index.html) يتصل بالسيرفر عبر public/shim.js.

## ماذا يوفّر
- تخزين دائم في ملف JSON (data/db.json) مع حفظ ذري.
- REST: `GET/PUT/PATCH/DELETE /api/c/:collection/:id` و `GET /api/c/:collection`
- تحديث لحظي لكل المتصفحات عبر SSE (`/api/events`) — نفس سلوك الموقع على claude.ai.
- نسخة احتياطية: `GET /api/export`.
- data/db.json يحتوي مسبقًا على مفاتيح أكواد الإدارة المشفّرة (admins/keys) لتعمل أكواد الدخول نفسها.

## ملاحظات أمان صريحة
- السيرفر لا يطبّق قواعد صلاحيات (على claude.ai كانت المنصة تتولاها). الأكواد والحسابات والأرقام الجامعية مخزّنة مشفّرة (RSA) من داخل الموقع، لكن أي شخص يصل للسيرفر يستطيع قراءة/كتابة المجموعات.
- شغّله خلف HTTPS (Nginx/Caddy أو Render/Railway/Fly) وقيّد الوصول (VPN، Basic Auth من الـ proxy، أو جدار شبكة الجامعة).
- لنقل البيانات الحالية من claude.ai: صدّر من لوحة البيانات (Excel) أو انسخها إلى data/db.json.
